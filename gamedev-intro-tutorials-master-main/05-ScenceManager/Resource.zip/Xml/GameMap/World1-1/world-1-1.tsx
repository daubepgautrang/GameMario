<? xml version = "1.0" encoding = "UTF-8" ?>
    <tileset version="1.4" tiledversion="1.4.2" name="world-1-1" tilewidth="48" tileheight="48" tilecount="870" columns="29">
        <image source="world-1-1.png" width="1392" height="1440" />
        <tile id="0">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="1">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="2">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="3">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="4">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="5">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="48">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="49">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="77">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="78">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="87">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="88">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="89">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="90">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="91">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="92">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="106">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="107">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="135">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="136">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="211">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="212">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="213">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="240">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="241">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="242">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="277">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="303">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="306">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="307">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="308">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="332">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="390">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="391">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="1.25" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="392">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="423">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="425">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="426">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
        <tile id="453">
            <objectgroup draworder="index" id="2">
                <object id="1" x="0" y="0" width="48" height="48" />
            </objectgroup>
        </tile>
    </tileset>
